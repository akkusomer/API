function getTemplatePageName() {
    const pathSegments = window.location.pathname.split('/').filter(Boolean);
    const lastSegment = pathSegments[pathSegments.length - 1];

    if (!lastSegment || !lastSegment.includes('.')) {
        return 'index.html';
    }

    return lastSegment.toLowerCase();
}

function updateSharedUserUI(currentUser) {
    if (!currentUser) {
        return;
    }

    const emailPrefix = (currentUser.email || 'atlas').split('@')[0];
    const avatarLetter = emailPrefix.charAt(0).toUpperCase() || 'A';
    const roleLabel = currentUser.role === 'Admin' ? 'Admin' : 'Kullanici';

    const userDisplayName = document.getElementById('user-display-name');
    if (userDisplayName) {
        userDisplayName.textContent = emailPrefix.toUpperCase();
    }

    const userDisplayRole = document.getElementById('user-display-role');
    if (userDisplayRole) {
        userDisplayRole.textContent = roleLabel;
    }

    const userAvatar = document.getElementById('user-avatar');
    if (userAvatar) {
        userAvatar.textContent = avatarLetter;
    }

    const adminName = document.getElementById('adminName');
    if (adminName) {
        adminName.textContent = currentUser.displayName || currentUser.email || 'Sistem Yoneticisi';
    }
}

function markActiveMenu() {
    const currentPath = getTemplatePageName();
    const menuItems = document.querySelectorAll('.menu-item[href]');

    menuItems.forEach(item => {
        const href = item.getAttribute('href');
        const isActive = href
            && href !== '#'
            && !href.startsWith('javascript:')
            && href.split('#')[0].toLowerCase() === currentPath;

        item.classList.toggle('active', Boolean(isActive));
    });
}

function ensureAdminShortcut(currentUser) {
    if (!currentUser || currentUser.role !== 'Admin') {
        return;
    }

    const sidebarMenu = document.querySelector('.sidebar-menu');
    if (!sidebarMenu || sidebarMenu.querySelector('a[href="admin.html"]')) {
        return;
    }

    const adminLink = document.createElement('a');
    adminLink.href = 'admin.html';
    adminLink.className = 'menu-item';
    adminLink.style.marginTop = '20px';
    adminLink.style.border = '1px dashed rgba(255,255,255,0.2)';
    adminLink.innerHTML = '<i class="fas fa-user-shield"></i> <span>Admin Paneli</span>';
    sidebarMenu.insertBefore(adminLink, sidebarMenu.lastElementChild);
}

function wireLogoutLinks() {
    document.querySelectorAll('a[href="login.html"], [data-logout]').forEach(link => {
        link.addEventListener('click', event => {
            event.preventDefault();
            apiClient.logout();
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const pageName = getTemplatePageName();
    const isLoginPage = pageName === 'login.html';
    const isAdminPage = pageName === 'admin.html';
    const currentUser = apiClient.getCurrentUser();

    if (!currentUser && !isLoginPage) {
        apiClient.clearSession();
        apiClient.redirectToLogin();
        return;
    }

    if (isLoginPage && currentUser) {
        window.location.replace(currentUser.role === 'Admin' ? 'admin.html' : 'index.html');
        return;
    }

    if (isAdminPage && currentUser?.role !== 'Admin') {
        window.location.replace('index.html');
        return;
    }

    updateSharedUserUI(currentUser);
    markActiveMenu();
    ensureAdminShortcut(currentUser);
    wireLogoutLinks();
});
